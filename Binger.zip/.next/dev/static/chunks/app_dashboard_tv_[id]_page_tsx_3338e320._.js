(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_83c95c14._.js",
  "static/chunks/node_modules_ad90c088._.js"
],
    source: "dynamic"
});
