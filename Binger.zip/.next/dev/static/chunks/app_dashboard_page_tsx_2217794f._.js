(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6f9e8905._.js",
  "static/chunks/app_dashboard_page_tsx_fb125c68._.js",
  "static/chunks/node_modules_swiper_6c5bd203._.css"
],
    source: "dynamic"
});
