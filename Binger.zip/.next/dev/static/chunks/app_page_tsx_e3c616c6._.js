(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_b71551f1._.js",
  "static/chunks/node_modules_@supabase_realtime-js_dist_module_a6b8d2d8._.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_4307daaa._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_58e31de5._.js",
  "static/chunks/node_modules_ba87f508._.js",
  "static/chunks/_24116641._.js"
],
    source: "dynamic"
});
