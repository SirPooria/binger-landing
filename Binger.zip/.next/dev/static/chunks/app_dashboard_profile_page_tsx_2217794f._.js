(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_dashboard_profile_page_tsx_b47db4f6._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_8ede6935._.js"
],
    source: "dynamic"
});
