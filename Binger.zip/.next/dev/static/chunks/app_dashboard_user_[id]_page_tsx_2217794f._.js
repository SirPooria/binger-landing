(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_dashboard_user_[id]_page_tsx_b7969ffc._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_39b1efea._.js"
],
    source: "dynamic"
});
