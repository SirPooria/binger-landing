(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_72474a4e._.js",
  "static/chunks/_9fba8b48._.js"
],
    source: "dynamic"
});
