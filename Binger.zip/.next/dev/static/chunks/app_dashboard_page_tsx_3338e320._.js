(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_70ff482e._.js",
  "static/chunks/node_modules_b6a789a4._.js",
  "static/chunks/node_modules_swiper_6c5bd203._.css"
],
    source: "dynamic"
});
