(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_dashboard_2af6c6ac._.js",
  "static/chunks/node_modules_a097597b._.js"
],
    source: "dynamic"
});
