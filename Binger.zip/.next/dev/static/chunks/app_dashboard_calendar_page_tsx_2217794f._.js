(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_dashboard_e7bbc557._.js",
  "static/chunks/node_modules_f5c3f395._.js"
],
    source: "dynamic"
});
