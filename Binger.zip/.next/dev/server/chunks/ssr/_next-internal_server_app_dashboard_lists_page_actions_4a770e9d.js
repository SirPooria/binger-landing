module.exports = [
"[project]/.next-internal/server/app/dashboard/lists/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_lists_page_actions_4a770e9d.js.map