module.exports = [
"[project]/.next-internal/server/app/dashboard/tv/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_tv_%5Bid%5D_page_actions_f2801230.js.map